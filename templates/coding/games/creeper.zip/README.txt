WELCOME TO THE CREEPER USELESS VIDEO GAME!!!

1. Run the file using python3, it should work on windows, linux, mac, and android as long as you have python3 installed.
2. Follow the on-screen directions...

DO NOT OPEN THE IMAGES. THE PROGRAM WILL DO IT FOR YOU!!
