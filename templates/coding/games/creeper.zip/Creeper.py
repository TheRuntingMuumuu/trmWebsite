"""
This is a fun random program that will decide between the 4 types of creepers to show. It is useless though... Unless you want to use it as some type of picture die...
"""
import random #so I Can randomely choose the creeper
import os # @TTR I tried the ansi escape codes, and they did not work...
from time import sleep #to add the loading times

def clear():
    if os.name == 'nt':
        _ = os.system('cls')
    else:
        _ = os.system('clear')

input("Press \"ENTER\" to determine which creeper will be shown...")
creeper = random.randint(1, 4) #what creeper to spawn
loadingMessage = random.randint(1, 7) #what loading message to show
spawnMessage = random.randint(1, 2) #what spawning message to use

clear()
print('------------------CREEPER PROGRAM------------------\n\n')
if loadingMessage == 1:
    print('Loading...')
elif loadingMessage == 2:
    print('Spawning creeper...')
elif loadingMessage == 3:
    print('1800-CRE-EPER')
elif loadingMessage == 4:
    print('Fast traveling to Caldera. Or is it mournhold??? Wait a second. Maybe the village...')
elif loadingMessage == 5:
    print('Determining what creeper to spawn...')
elif loadingMessage == 6:
    if creeper == 1:
        print('you better bring some obsidian... I think I found the wrong one... ')
    elif creeper == 4:
        print('oops... thats definitely not a creeper...')
    else:
        print('I think I can see him in the distance, he sure is ugly (don\'t tell him I said that)')
elif loadingMessage == 7:
    print('I cant think of a message... Just ignore this...')

sleep(random.randint(1, 4)) #how long to load for
print('\r')

if creeper == 1:
    if spawnMessage == 1:
        print('AAAAAA!!!! HE\'S GOING TO EXPLODE')
    else:
        print("A MINECRAFT CREEPER HAS SPAWNED")
    os.startfile('mc.jpg')
elif creeper == 2:
    print("THE ESO CREEPER HAS ARRIVED")
    os.startfile('eso.jpg')
elif creeper == 3:
    if spawnMessage == 1:
        print('Welcome to Caldera...')
    else:
        print("THE BEST MERCHANT IN MORROWIND HAS SPAWNED... AKA THE CREEPER")
    os.startfile('morrowind.png')
elif creeper == 4:
    if spawnMessage == 1:
        print('That looks awfully like a pig...')
    else:
        print("NOTCH SPAWNED THIS CREEPER. HE MESSED UP THE DIMENTIONS")
    os.startfile('notch.jpg')
