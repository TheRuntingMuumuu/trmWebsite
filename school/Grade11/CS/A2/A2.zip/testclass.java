/**
 * This is the test class for the program that will be the cashier program for the Ottawa Department Store. It will have 2 departments (Hardware and Seasonal). It will allow the cashier to add a certain number of
 * each item to a receipt, or to add a new item if that item does not exist. Finally once the cashier is done, it will output a receipt with useful information for the customer.
 *
 * @author (TRM)
 * @version (November 18 2021)
 */
//import the scanner to gather user input
import java.util.Scanner;

//import arraylists for storing the items for each department
import java.util.ArrayList;

public class DaigleOttawaStoreAssignment
{
    //create an arraylist for the hardware department
    public static ArrayList<Hardware> hardwareList = new ArrayList<Hardware>();

    //create an arraylist for the seasonal department
    public static ArrayList<Seasonal> seasonalList = new ArrayList<Seasonal>();

    public static void main(String[] args)
    {
        //declare and initialise varible for error trapping
        boolean booTryCatch;

        //declare and initialise variable for whether the user wants to enter another item
        boolean booNewItem = true;

        //declare variable for the department that the user selected
        byte bytDepartmentSelected;

        //declare variable for the item that is selected
        byte bytSelectedItem = 0;

        //declare variable to continue looping if the user enters a wrong value when creating new items
        boolean booNewItemConfirm = false;

        //declare variables to hold the information gathered from the user for creating a new item before it is passed into the constructor
        String strNewItemName;
        float fltNewItemPrice = 0;
        byte bytNewItemQuantity = 0;
        boolean booNewItemGas;

        //declare variable for the total price
        float fltTotal = 0.00f;

        //declare variable for the discount that may be applied to the total
        float fltDiscount = 0.00f;

        //hardcodes 4 items for each of the 2 departments
        hardwareList.add(new Hardware("Chainsaw", 299.99f, true));
        hardwareList.add(new Hardware("Drill", 149.99f, false));
        hardwareList.add(new Hardware("Hammer", 29.99f, false));
        hardwareList.add(new Hardware("Sledgehammer", 129.99f, false));
        seasonalList.add(new Seasonal("Christmas Tree (fake)", 134.89f));
        seasonalList.add(new Seasonal("Shovel", 15.25f));
        seasonalList.add(new Seasonal("Christmas Lights", 49.99f));
        seasonalList.add(new Seasonal("Power Cord", 22.99f));

        //while loop to loop while the user still wants to enter another item
        while(booNewItem)
        {
            //asks the user if they want to enter an item
            System.out.println("Do you want to enter an item?");

            //gather user input from the userYN method and assign it to the booNewItem variable to be used
            booNewItem = userYN();

            //if statement to only proceed if the user does want to enter an item
            if (booNewItem)
            {
                //outputs what is currently in the cart by printing the receipt passing in the true parameter to show it in condensed mode. That will tell the method to only show some of the information. Also enter some new lines
                System.out.println("**** Cart ****");
                printReceipt(fltTotal, true);
                System.out.println("\n");

                //run the departmentchoice method to determine the department and assign it to the varialbe
                bytDepartmentSelected = departmentChoice();

                //if statement to output different items depending on the department
                if (bytDepartmentSelected == 1)
                {
                    //do while loop and try catch to trap any errors and then reloop to ask the user again.
                    do
                    {
                        try
                        {
                            //asks the user what item they want to pick (or enter 0 for new item)
                            System.out.println("What item do you want to pick or press 0 for a new item");

                            //for loop to ourput the entire arraylist with a number before it
                            for (int i = 0; i < hardwareList.size(); i++)
                            {
                                System.out.println((i+1) + " " + hardwareList.get(i).getName());
                            }

                            //get user input and assign it to the variable
                            bytSelectedItem = new Scanner(System.in).nextByte();

                            //if statement to check if that is a valid entry (if it is in the arraylist) so the arraylist does not error out
                            if (bytSelectedItem > hardwareList.size() || bytSelectedItem < 0)
                            {
                                //tells the user to enter a value in the correct range adn sets the try catch to true to loop again
                                System.out.println("Please enter a value in the range of 1 - " + hardwareList.size() + " or 0 if you want to add a new item");
                                booTryCatch = true;
                            }
                            else
                            {
                                //set the try catch variable to false to stop looping
                                booTryCatch = false;
                            }
                        }
                        catch(Exception e)
                        {
                            //tell the user to enter the correct type and set the try catch to true to loop again
                            System.out.println("Please enter the selection as a number");
                            booTryCatch = true;
                        }
                    }while(booTryCatch);

                    //if statement to check if the result does not equal 0; the user does not want to create a new entry
                    if (bytSelectedItem != 0)
                    {
                        //increments the quantity of that item on the arraylist
                        hardwareList.get(bytSelectedItem-1).setQuantity(amountToBuy());
                    }
                    else if (bytSelectedItem == 0)
                    {
                        //do while loop to loop until the user confirms that they entered the right information
                        do
                        {
                            //asks the user to enter the name and assigns it to the correct variable
                            System.out.println("Please enter the name of the new item");
                            strNewItemName = new Scanner(System.in).nextLine();

                            //do while and try catch to catch errors since it is a float
                            do
                            {
                                try
                                {
                                    //asks the user to enter the price and assigns it to the correct variable
                                    System.out.println("Please enter the price of the new item");
                                    fltNewItemPrice = new Scanner(System.in).nextFloat();

                                    //sets the try catch to false to exit the loop if the user already made an error
                                    booTryCatch = false;
                                }
                                catch(Exception e)
                                {
                                    //tells the user of the error and loops back around
                                    System.out.println("Please enter the price as a number");
                                    booTryCatch = true;
                                }
                            }while(booTryCatch);

                            //do while and try catch to catch errors since it is a float
                            do
                            {
                                try
                                {
                                    //asks the user to enter the quantity to add and assigns it to the correct variable
                                    System.out.println("Please enter the quantity of the new item to add or remove from the cart");
                                    bytNewItemQuantity = new Scanner(System.in).nextByte();

                                    //sets the try catch to false to exit the loop if the user already made an error
                                    booTryCatch = false;
                                }
                                catch(Exception e)
                                {
                                    //tells the user of the error and loops back around
                                    System.out.println("Please enter the quantity as a number");
                                    booTryCatch = true;
                                }
                            }while(booTryCatch);

                            //asks the user to enter if the item is gas powered and assigns it to the correct variable
                            System.out.println("Is the item gas powered?");
                            booNewItemGas = userYN();

                            //Asks the user if what they entered is correct
                            System.out.println("This is what we got. \n\tName: " + strNewItemName + "\n\tPrice: " + fltNewItemPrice + "\n\tQuantity to Add: " + bytNewItemQuantity + "\n\tGas Powered: " + booNewItemGas + "\nIs it correct?");
                            booNewItemConfirm = userYN();
                        }while(booNewItemConfirm == false); //false so I can reuse the userYN method without changing anything

                        //create an object using the parameters just gathered in the hardware arraylist
                        hardwareList.add(new Hardware(strNewItemName, fltNewItemPrice, bytNewItemQuantity, booNewItemGas));
                    }
                }
                else if (bytDepartmentSelected == 2)
                {
                    //do while loop and try catch to trap any errors and then reloop to ask the user again.
                    do
                    {
                        try
                        {
                            //asks the user what item they want to pick (or enter 0 for new item)
                            System.out.println("What item do you want to pick or press 0 for a new item");

                            //for loop to ourput the entire arraylist with a number before it
                            for (int i = 0; i < seasonalList.size(); i++)
                            {
                                System.out.println((i+1) + " " + seasonalList.get(i).getName());
                            }

                            //get user input and assign it to the variable
                            bytSelectedItem = new Scanner(System.in).nextByte();

                            //if statement to check if that is a valid entry (if it is in the arraylist) so the arraylist does not error out
                            if (bytSelectedItem > seasonalList.size() || bytSelectedItem < 0)
                            {
                                //tells the user to enter a value in the correct range adn sets the try catch to true to loop again
                                System.out.println("Please enter a value in the range of 1 - " + seasonalList.size() + " or 0 if you want to add a new item");
                                booTryCatch = true;
                            }
                            else
                            {
                                //set the try catch variable to false to stop looping
                                booTryCatch = false;
                            }
                        }
                        catch(Exception e)
                        {
                            //tell the user to enter the correct type and set the try catch to true to loop again
                            System.out.println("Please enter the selection as a number");
                            booTryCatch = true;
                        }
                    }while(booTryCatch);

                    //if statement to check if the result does not equal 0; the user does not want to create a new entry
                    if (bytSelectedItem != 0)
                    {
                        //increments the quantity of that item on the arraylist
                        seasonalList.get(bytSelectedItem-1).setQuantity(amountToBuy());
                    }
                    else if (bytSelectedItem == 0)
                    {
                        //do while loop to loop until the user confirms that they entered the right information
                        do
                        {
                            //asks the user to enter the name and assigns it to the correct variable
                            System.out.println("Please enter the name of the new item");
                            strNewItemName = new Scanner(System.in).nextLine();

                            //do while and try catch to catch errors since it is a float
                            do
                            {
                                try
                                {
                                    //asks the user to enter the price and assigns it to the correct variable
                                    System.out.println("Please enter the price of the new item");
                                    fltNewItemPrice = new Scanner(System.in).nextFloat();

                                    //sets the try catch to false to exit the loop if the user already made an error
                                    booTryCatch = false;
                                }
                                catch(Exception e)
                                {
                                    //tells the user of the error and loops back around
                                    System.out.println("Please enter the price as a number");
                                    booTryCatch = true;
                                }
                            }while(booTryCatch);

                            //do while and try catch to catch errors since it is a float
                            do
                            {
                                try
                                {
                                    //asks the user to enter the quantity to add and assigns it to the correct variable
                                    System.out.println("Please enter the quantity of the new item to add or remove from the cart");
                                    bytNewItemQuantity = new Scanner(System.in).nextByte();

                                    //sets the try catch to false to exit the loop if the user already made an error
                                    booTryCatch = false;
                                }
                                catch(Exception e)
                                {
                                    //tells the user of the error and loops back around
                                    System.out.println("Please enter the quantity as a number");
                                    booTryCatch = true;
                                }
                            }while(booTryCatch);

                            //Asks the user if what they entered is correct
                            System.out.println("This is what we got. \n\tName: " + strNewItemName + "\n\tPrice: " + fltNewItemPrice + "\n\tQuantity to Add: " + bytNewItemQuantity + "\nIs it correct?");
                            booNewItemConfirm = userYN();
                        }while(booNewItemConfirm == false); //false so I can reuse the userYN method without changing anything since it will return true if the user says that it is correct

                        //create an object using the parameters just gathered in the seasonal arraylist
                        seasonalList.add(new Seasonal(strNewItemName, fltNewItemPrice, bytNewItemQuantity));
                    }
                }
            }
        }

        //asks the user if they want to add a discount
        System.out.println("Do you want to add a discount?");

        //checks if they want to by using the userYN method
        if (userYN())
        {
            // do while and try catch loop since it will be accepting a number
            do
            {
                try
                {
                    //asks the user to enter the discount
                    System.out.println("Please enter the discount amount in dollars");

                    //assgns the user input to a variable
                    fltDiscount = new Scanner(System.in).nextFloat();

                    //applies the discount to the subtotal and then informs the user of the new price
                    System.out.println("The discount of $" + fltDiscount + " has been applied.");
                    fltTotal -= fltDiscount;

                    //sets the try catch to false to stop looping
                    booTryCatch = false;

                }catch(Exception e)
                {
                    //tells the user to enter the correct type and sets the try catch variable to true to loop again
                    System.out.println("Please enter the discount as a number");
                    booTryCatch = true;

                }
            }while(booTryCatch);
        }

        //outputs the receipt using the printreceipt method. Sends the false parameter to tell the method to print all the information (total, tax, formatting, gas powered, price) not just some of them
        printReceipt(fltTotal, false);
    }

    //byte method to ask the user for the department that they want
    public static byte departmentChoice()
    {
        //declare and initialise varible for error trapping
        boolean booTryCatch;

        //declare variable for the department that the user selected
        byte bytDepartmentSelected = 0;

        //do while loop to reprompt the user if they enter a wrong value
        do
        {
            //try and catch block to catch errors
            try
            {
                //asks the user to enter the department they want to select
                System.out.println("Please enter the department that you would like to select: \n1 Hardware\n2 Seasonal");

                //Gather user input and assign
                bytDepartmentSelected = new Scanner(System.in).nextByte();

                //if statement to determine if the number is a valid one
                if (bytDepartmentSelected != 1 && bytDepartmentSelected != 2)
                {
                    //sets the try catch variable to true to loop again and tell the user of the error
                    booTryCatch = true;
                    System.out.println("Please enter a valid department");
                }
                else
                {
                    //sets the try and catch variable to true to not loop again.
                    booTryCatch = false;
                }
            }
            catch(Exception e)
            {
                //tells the user to enter an integer
                System.out.println("Please enter the department choice as a number");

                //sets the try and catch to true to loop again
                booTryCatch = true;
            }
        }while(booTryCatch);

        //returns the department selected to where the method was called
        return bytDepartmentSelected;
    }

    //method to print the reciept which will have all items, and the totals
    public static void printReceipt(float fltTotal, boolean booCondensed)
    {
        //declares short variables for the number of items for each department on the receipt
        short shrNumOfItemsHardware = 0;
        short shrNumOfItemsSeasonal = 0;

        //removes this if the user wants the output to be condensed
        if (booCondensed == false)
        {
            //outputs some text to make the output look better
            System.out.println("\n************* Reciept *************\n      Ottawa Department Store\n");
        }

        //for each loop to loop through the hardware department and output all items with a quantity of more than 1, and keep track of the total.
        for (Hardware element: hardwareList)
        {
            //if statement to check if there is more than 0 of the item
            if (element.getQuantity() > 0)
            {
                //output only the quantity and name if condensed
                if (booCondensed)
                {
                    //output just the title and the quantity
                    System.out.println(element.getQuantity() + " " + element.getName());
                }
                else
                {
                    //output the item to the screen using the toString method
                    System.out.println(element);
                }

                //add all the items value to the total variable
                fltTotal += element.getPrice()*element.getQuantity();

                //increase the number of items by the quantity
                shrNumOfItemsHardware += element.getQuantity();
            }
        }

        //for each loop to loop through the seasonal department and output all items with a quantity of more than 1, and keep track of the total.
        for (Seasonal element: seasonalList)
        {
            //if statement to check if there is more than 0 of the item
            if (element.getQuantity() > 0)
            {
                //output only the quantity and name if condensed
                if (booCondensed)
                {
                    //output just the title and the quantity
                    System.out.println(element.getQuantity() + " " + element.getName());
                }
                else
                {
                    //output the item to the screen using the toString method
                    System.out.println(element);
                }

                //add all the items value to the total variable
                fltTotal += element.getPrice()*element.getQuantity();

                //increases the number of items by the quantity
                shrNumOfItemsSeasonal += element.getQuantity();
            }
        }

        //removes this if the user wants the output to be condensed
        if (booCondensed == false)
        {
            //outputs the total from each department
            System.out.println("You bought " + shrNumOfItemsHardware + " items in Hardware");
            System.out.println("You bought " + shrNumOfItemsSeasonal + " items in Seasonal");

            //outputs the total of items bought
            System.out.println("You bought " + (shrNumOfItemsHardware + shrNumOfItemsSeasonal) + " items in total");

            //outputs the total, tax, and the subtotal and does the calculations required
            System.out.printf("Subtotal: %.2f \nTax: %.2f \nTotal: %.2f", fltTotal, (fltTotal*0.13), (fltTotal*1.13));

            //outputs some text to make it look better
            System.out.println("\n************** * * * **************");
        }
        else
        {
            //outputs the subtotal
            System.out.printf("Subtotal: %.2f", fltTotal);
        }
    }

    //byte method to ask the user to enter the amount they want to buy and then return that number
    public static byte amountToBuy()
    {
        //declare variable to hold the number
        byte bytAmountToBuy = 0;

        //declare variable to catch errors
        boolean booTryCatch = false;

        //do while loop to loop if the user enters a wrong input
        do
        {
            //try catch to catch if the user enters the wrong data type
            try
            {
                //prompt the user
                System.out.println("Please enter the quantity of the item to add or remove from the cart");

                //gather the input and assign it to the variable
                bytAmountToBuy = new Scanner(System.in).nextByte();

                //sets the try catch variable to false
                booTryCatch = false;
            }
            catch(Exception e)
            {
                //tell the user that they entered the wrong type
                System.out.println("Please enter the amount as a number (such as 1)");

                //set the try catch variable to true to reloop and reask the user
                booTryCatch = true;
            }
        }while(booTryCatch);

        //return the amount that the user specified to where the method was called
        return bytAmountToBuy;
    }

    //void method to take user input and output a true or false depending on whether or not they pick yes or no
    public static boolean userYN()
    {
        //declare variable to take the user's input
        String strUserInput;

        //declare variable to store the first character of the user's input
        char chrInput;

        //declare boolean variable to return that will have the user's response
        boolean booUserResponse = false;

        //declare boolean for try and catch
        boolean booTryCatch = false;


        do
        {
            //gather user input and assign it to the variable
            strUserInput = new Scanner(System.in).next();

            //try catch block to catch an error in case the user enters nothing
            try
            {
                //take the first character of the user input and set it to lower
                strUserInput = strUserInput.toLowerCase();
                chrInput = strUserInput.charAt(0);
            }
            catch(Exception e)
            {
                //if the user entered nothing, assign an incorrect value to the chrInput so it will error out later
                chrInput = 'a';
            }

            //if statement to check if they entered a y, n, or something else
            if (chrInput == 'y')
            {
                //sets the users response to true, this will be returned
                booUserResponse = true;

                //sets the try catch to false to stop looping
                booTryCatch = false;
            }
            else if (chrInput == 'n')
            {
                //sets the users response to false, this will be returned
                booUserResponse = false;

                //sets the try catch to false to stop looping
                booTryCatch = false;
            }
            else
            {
                //tells the user that they should enter the correct input
                System.out.println("Please enter either a Yes or No");

                //sets the try catch to true to continue looping
                booTryCatch = true;
            }
        }while(booTryCatch);

        //return the either true or false to where the method was called
        return booUserResponse;
    }
}
