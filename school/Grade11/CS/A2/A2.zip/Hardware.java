
/**
 * This is the class for the hardware department of the Ottawa Department Store. It has variables, get/set methods, and the toString method about hardware such as drills and lawnmowers.
 *
 * @author (TRM)
 * @version (November 18 2021)
 */
public class Hardware
{
    //declare private variables for the name of the product, the quantity purchaced, whether the item is gas powered, and the price of the item.
    private String strName;
    private float fltPrice;
    private byte bytQuantity;
    private boolean booGasPowered;


    //constructor for all the variables
    Hardware(String n, float p, byte q, boolean g)
    {
        this.strName = n;
        this.fltPrice = p;
        this.bytQuantity = q;
        this.booGasPowered = g;
    }

    //overloaded constructor for just the name and price
    Hardware(String n, float p, boolean g)
    {
        this.strName = n;
        this.fltPrice = p;
        this.bytQuantity = 0;
        this.booGasPowered = g;
    }

    //default constructor
    Hardware()
    {
        this.strName = "Unknown";
        this.fltPrice = 0.00f;
        this.bytQuantity = 0;
        this.booGasPowered = false;
    }

    //get methods
    public String getName()
    {
        return this.strName;
    }

    public float getPrice()
    {
        return this.fltPrice;
    }

    public byte getQuantity()
    {
        return this.bytQuantity;
    }

    public boolean getGasPowered()
    {
        return this.booGasPowered;
    }

    //set methods
    public void setQuantity(byte q)
    {
        //if statement to determine if adding q will make the quantity negative
        if ((this.bytQuantity + q) >= 0)
        {
            //increases the quantity by q
            this.bytQuantity += q;
        }
    }

    //toString method to return all the information about this item
    public String toString()
    {
        return bytQuantity + " " + strName + "\n\tDepartment : Hardware\n\t" + "Gas: " + booGasPowered + "\n\t" + fltPrice + "\n";
    }
}
