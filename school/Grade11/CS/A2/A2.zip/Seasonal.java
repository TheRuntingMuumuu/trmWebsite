
/**
 * This is the class for the seasonal department of the Ottawa Department Store. It has variables about seasonal stuff such as lights, and christmas trees.
 *
 * @author (TRM)
 * @version (November 18 2021)
 */
public class Seasonal
{
    //declare private variables for the name of the product, the quantity purchaced, and the price of the item.
    private String strName;
    private float fltPrice;
    private byte bytQuantity;

    //constructor for all the variables
    Seasonal(String n, float p, byte q)
    {
        this.strName = n;
        this.fltPrice = p;
        this.bytQuantity = q;
    }

    //overloaded constructor for just the name and price
    Seasonal(String n, float p)
    {
        this.strName = n;
        this.fltPrice = p;
        this.bytQuantity = 0;
    }

    //default constructor
    Seasonal()
    {
        this.strName = "Unknown";
        this.fltPrice = 0.00f;
        this.bytQuantity = 0;
    }

    //get methods
    public String getName()
    {
        return this.strName;
    }

    public float getPrice()
    {
        return this.fltPrice;
    }

    public byte getQuantity()
    {
        return this.bytQuantity;
    }

    //set methods
    public void setQuantity(byte q)
    {
        //if statement to determine if adding q will make the quantity negative
        if ((this.bytQuantity + q) >= 0)
        {
            //increases the quantity by q
            this.bytQuantity += q;
        }
    }

    //toString method to return all the information about this item
    public String toString()
    {
        return bytQuantity + " " + strName + "\n\tDepartment : Seasonal\n\t" + fltPrice + "\n";
    }
}
